import logging
import uvicorn
import pickle
import numpy as np
from fastapi import FastAPI,Query
from pydantic import BaseModel
from Pre.FeatureExtraction import FeatureExtraction,GetFlashWaveFeature
from models.InceptionTime import InceptionTimeClassfication

logging.basicConfig(
    level=logging.INFO,  # 设置日志级别为INFO
    format='%(asctime)s - %(levelname)s - %(message)s',  # 设置日志格式
    filename='./logs/demo.log',  # 设置日志输出文件
    filemode='a'  # 设置日志文件模式为追加模式
)

# 初始化模型
model = InceptionTimeClassfication("./weights/InceptionTime.onnx")

app = FastAPI()


class RequestData(BaseModel):
    data: str
    length: str

@app.get("/predict")
async def predict(data:str=Query,length:str=Query):
    logging.info("处理请求，这是开头\n")
    dataList,length = [int(numStr)  for numStr in data.split("==")[1:-1]],int(length)
    if length < 1500 :
        logging.error("上传的json中的data数据太短！")
        return -1
    logging.info(f"接收到的数据为：{dataList}")
    dataArray = np.array(dataList)
    dataInput = FeatureExtraction(dataArray)
    logging.info(f"输入模型数据的信息为：{dataInput}")
    res = model(dataInput)
    logging.info(f"最终雷电数据的类别为：{res}")
    logging.info("处理请求，这是结尾\n")
    return "class="+str(res)

@app.get("/FeatureExtraction")
async def predict(data:str=Query,length:str=Query):
    logging.info("处理请求，这是开头\n")
    dataList,length = [int(numStr)  for numStr in data.split("==")[1:-1]],int(length)
    if length < 1500 :
        logging.error("上传的json中的data数据太短！")
        return -1
    logging.info(f"接收到的数据为：{dataList}")
    flag,eigenvalue = GetFlashWaveFeature(dataList)
    logging.info(f"处理后的的特征数据为：{eigenvalue}")
    if flag == -1:
        return "class=0"
    else:
        return eigenvalue

@app.get("/process")
async def predict(data:str=Query,length:str=Query):
    logging.info("处理请求，这是开头\n")
    dataList,length = [int(numStr)  for numStr in data.split("==")[1:-1]],int(length)
    if length < 1500 :
        logging.error("上传的json中的data数据太短！")
        return -1
    logging.info(f"接收到的数据为：{dataList}")
    dataArray = np.array(dataList)
    dataInput = FeatureExtraction(dataArray)
    logging.info(f"输入模型数据的信息为：{dataInput}")
    res = model(dataInput)
    logging.info(f"最终雷电数据的类别为：{res}")
    logging.info(f"接收到的数据为：{dataList}")
    falg,eigenvalue = GetFlashWaveFeature(dataList)
    logging.info(f"处理后的的特征数据为：{eigenvalue}")
    if flag == -1 or res==0:
        return "class=0"
    else:
        return res +"###" + eigenvalue

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)