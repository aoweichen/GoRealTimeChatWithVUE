import onnx
import onnxruntime
import numpy as np

def standardize(data):
    mean = np.mean(data, axis=(1, 2), keepdims=True)
    std = np.std(data, axis=(1, 2), keepdims=True)
    normalized_data = (data - mean) / std
    return normalized_data


class InceptionTimeClassfication:

    def __init__(self,model_path):
        onnx_model = onnx.load(model_path)
        self.ortModel = onnxruntime.InferenceSession(onnx_model.SerializeToString())


    def __preprocess__(self,data):
        # data => np.darray --> [1000]
        data0 =  np.expand_dims(data, axis=0).astype(np.float32)
        # data1 => np.darray --> [1,1,1000]
        data1 =  np.expand_dims(data0, axis=0).astype(np.float32)
        # 数据标准化
        data2 = standardize(data1)
        return data2

    def __call__(self,data):
        # 得到输入数据
        inputdata = self.__preprocess__(data)
        # 推理
        outputdata = self.ortModel.run(None, {'input': inputdata})[0]
        # 得到最可能的结果
        pred_label = int(np.argmax(outputdata))

        return pred_label