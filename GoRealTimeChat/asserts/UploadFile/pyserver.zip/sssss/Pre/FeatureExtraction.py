import logging
import numpy as np
import matplotlib.pyplot as plt

def FeatureExtraction(data):
    # 判断数据中的最大值是否大于最小值的相反数，如果是，则最大值为最大值，否则为最小值的相反数
    if (max(data) > -min(data)):
        maximum = max(data)
    else:
        maximum = min(data)
    # 打印原始数据中的最大值和最小值的相反数
    logging.info(f"原始数据中的最大值为：{max(data)},最小值的相反数为：{-min(data)}")
    # 对数据进行归一化处理，即将每个元素除以最大值
    normalized_data = [i / maximum for i in data]
    logging.info(f"对数据进行归一化处理，即将每个元素除以最大值,最后的结果为：{normalized_data}")
    # 将归一化后的数据转换为NumPy数组
    normalized_npdata = np.array(normalized_data)
    # 找到大于0.3的元素的下标
    where = np.where(normalized_npdata > 0.3)[0]
    logging.info(f"找到大于0.3的元素的下标,最后的坐标数组为为：{where}")
    # 获取第一个大于0.3的下标，并将其减去150
    preamble = where[0]  # 返回第一个大于0.3的下标
    preamble = max(0, preamble - 150)
    logging.info(f"获取第一个大于0.3的下标，并将其减去150，最后的值为：{preamble}")
    # 设置样本数量为1000
    n_samples = 1000
    # 从预处理后的数据中截取一段子序列，起始位置为preamble
    output = normalized_data[preamble:]
    # 打印截取后的子序列长度
    logging.info(f"截取后的子序列长度为：{preamble}")
    # 如果截取后的子序列长度大于n_samples，则截取前n_samples个元素
    if len(output) > n_samples:
        output = output[:n_samples]  # 截断过长的后续
    # 如果截取后的子序列长度小于n_samples，则在末尾补充0，使其长度达到n_samples
    if len(output) < n_samples:
        output = np.concatenate((output, np.zeros(n_samples - len(output))))  # 后续补0
    # 打印最终处理后的子序列长度
    logging.info(f"最终处理后的子序列长度：{preamble}")
    # 返回处理后的子序列
    return output


def GetFlashWaveFeature(data):
    return compute_wave(data)


#函数接收一个1500采用点的磁场矢量和，返回一个包含特征值的字典类型，特征值单位均为us
def compute_wave(cichang):
    #可计算特征值标志
    flag = 1

    # 绘制直方图
    n, bins = np.histogram(cichang, bins=20)

    # 找到频数最大的区间
    max_index = np.argmax(n)
    max_bin_left = bins[max_index]
    max_bin_right = bins[max_index+1]
    ref = (max_bin_left + max_bin_right)/2


    # 二次绘制直方图
    n, bins = np.histogram(cichang, bins=50, range=[max_bin_left,max_bin_right])

    # 找到频数最大的区间
    max_index = np.argmax(n)
    max_bin_left = bins[max_index]
    max_bin_right = bins[max_index+1]
    ref = (max_bin_left + max_bin_right)/2

    # 计算强度，峰值时间，反冲幅度
    cichang = [-x for x in cichang]
    if abs(np.max(cichang))<abs(np.min(cichang)):
        cichang = [-x for x in cichang]
    Intensity = np.max(cichang) - ref
    Intensity_time = np.argmax(cichang)
    Backlash_range = ref - np.min(cichang)
    Backlash_time = np.argmin(cichang[0:1500])
    # print(Backlash_time)

    # print("强度为%f，峰值时间为%f，反冲幅度为%f" %(Intensity, Intensity_time, Backlash_range))

    #归一化处理
    boundary = Intensity+500
    cichang_1 = cichang - ref
    cichang_1 = cichang_1/boundary


    value_10 = Intensity*0.1#幅值10%线
    value_90 = Intensity*0.9#幅值90%线
    #计算上升沿
    value_10_1 = value_10/boundary
    value_90_1 = value_90/boundary

    find_zero = np.diff(np.sign(cichang_1-value_10_1))
    index_up = np.where(find_zero > 0)[0]
    index_down = np.where(find_zero < 0)[0]

    find_top = np.diff(np.sign(cichang_1-value_90_1))
    index_up_2 = np.where(find_top > 0)
    index_down_2 = np.where(find_top < 0)

    if len(np.where((index_up - Intensity_time) < 0)[0]) != 0 and len(np.where((index_up_2 - Intensity_time) < 0)[0]) != 0:
        nearest_zero_index = np.where((index_up - Intensity_time) < 0)[0][-1]
        nearest_zero = index_up[nearest_zero_index]
        nearest_top_index = np.where((index_up_2 - Intensity_time) < 0)[0][0]
        nearest_top = index_up_2[nearest_top_index][0]
        rise_time = nearest_top - nearest_zero
    else:
        rise_time = 0
        flag = -1

    #计算过零时间
    find_zero = np.diff(np.sign(cichang_1))
    index_up = np.where(find_zero > 0)[0]
    index_down = np.where(find_zero < 0)[0]

    if len(np.where((index_up - Intensity_time) < 0)[0]) * len(np.where((index_down - Backlash_time) < 0)[0]) * len(np.where((index_up - Backlash_time) > 0)[0]) != 0:
        nearest_zero_index = np.where((index_up - Intensity_time) < 0)[0][-1]
        nearest_zero_index_2 = np.where((index_down - Backlash_time) < 0)[0][-1]
        nearest_zero_index_3 = np.where((index_up - Backlash_time) > 0)[0][0]
        nearest_zero = index_up[nearest_zero_index]
        nearest_zero_2 = index_down[nearest_zero_index_2]
        nearest_zero_3 = index_up[nearest_zero_index_3]

        pass_zero_time1 = nearest_zero_2-nearest_zero
        pass_zero_time2 = nearest_zero_3-nearest_zero_2
    else:
        pass_zero_time1 = pass_zero_time2 = 0
        flag = -1

    logging.info(f"参考线值的为：{ref}")
    logging.info("强度为%f，峰值时间为%fus，反冲幅度为%f" %(Intensity, Intensity_time/2, Backlash_range))
    logging.info("上升沿时间为%fus" %(rise_time/2))
    logging.info("第一次过零时间为%fus，第二次过零时间为%fus" %(pass_zero_time1/2,pass_zero_time2/2))

    # eigenvalue = {'refvalue':ref, 'intensity':Intensity, 'peak_duration':Intensity_time/2, 'Backlash_range':Backlash_range, 'risetime':rise_time/2, 'pass_zero_time1':pass_zero_time1/2, 'pass_zero_time2':pass_zero_time2/2}
    eigenvalue = "refvalue="+str(ref)+",intensity="+str(Intensity)+",peak_duration="+str(Intensity_time/2)+",Backlash_range="+str(Backlash_range)+",risetime="+str(rise_time/2)+",pass_zero_time1="+str(pass_zero_time1/2)+",pass_zero_time2="+str(pass_zero_time2/2)
    return flag,eigenvalue